# Lab 2 TypeScript

## Introduction

The basic Node.js application on TypeScript.

## Installing

```bash
git clone https://github.com/sergkudinov/ece-nodejs-2-typescript.git
cd ece-nodejs-2-typescript
npm install
```

## Build

```bash
npm run build
```

## Development

```bash
npm run dev
```

## Contributors
